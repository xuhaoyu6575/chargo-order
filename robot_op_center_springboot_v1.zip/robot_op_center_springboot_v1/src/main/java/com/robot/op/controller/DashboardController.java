
package com.robot.op.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin("*")
public class DashboardController {

    // 完单率逻辑：实际充电度数 >= 下单度数 [cite: 4]
    @GetMapping("/completion-rate")
    public Map<String, Object> getCompletionRate() {
        Map<String, Object> data = new HashMap<>();
        data.put("satisfied", 1150); // 实际 >= 预估 [cite: 4]
        data.put("unsatisfied", 100);
        data.put("rate", "92%");
        return data;
    }

    // 全流程耗时：响应、行驶、插枪、充电、拔枪 [cite: 4]
    @GetMapping("/process-time")
    public List<Map<String, Object>> getProcessTime() {
        return Arrays.asList(
            createTimeMap("响应耗时", 2),   // 派单-下单 [cite: 4]
            createTimeMap("行驶耗时", 5),   // 到达-派单 [cite: 4]
            createTimeMap("插枪耗时", 3),   // 插枪-到达 [cite: 4]
            createTimeMap("充电耗时", 45),  // 完成-插枪 [cite: 4]
            createTimeMap("拔枪耗时", 2)    // 拔枪-完成 [cite: 4]
        );
    }

    private Map<String, Object> createTimeMap(String name, int minutes) {
        Map<String, Object> map = new HashMap<>();
        map.put("name", name);
        map.put("value", minutes);
        return map;
    }
}
