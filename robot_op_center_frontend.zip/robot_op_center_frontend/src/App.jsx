
import React, { useState, useEffect } from 'react';
import ReactECharts from 'echarts-for-react';
import { api } from './services/api';

const Dashboard = () => {
  return (
    <div className="bg-[#06162d] min-h-screen text-white p-6 font-sans">
      {/* Header */}
      <div className="flex justify-between items-center mb-6 border-b border-cyan-900 pb-4">
        <h1 className="text-3xl font-bold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
          移动储能机器人运营中心
        </h1>
        <div className="flex gap-4 text-sm">
          <select className="bg-[#0b223d] border border-cyan-800 p-1 rounded">
            <option>全部站点</option>
          </select>
          <select className="bg-[#0b223d] border border-cyan-800 p-1 rounded">
            <option>最近7天</option>
          </select>
        </div>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-3 gap-6 mb-6">
        <div className="bg-[#0b223d]/50 border-l-4 border-cyan-500 p-4 shadow-lg shadow-cyan-900/20">
          <p className="text-gray-400 text-sm">总订单量</p>
          <p className="text-3xl font-mono text-cyan-400">1,250</p>
        </div>
        <div className="bg-[#0b223d]/50 border-l-4 border-cyan-500 p-4 shadow-lg shadow-cyan-900/20">
          <p className="text-gray-400 text-sm">总充电度数 (kWh)</p>
          <p className="text-3xl font-mono text-cyan-400">35,400</p>
        </div>
        <div className="bg-[#0b223d]/50 border-l-4 border-cyan-500 p-4 shadow-lg shadow-cyan-900/20">
          <p className="text-gray-400 text-sm">活跃机器人</p>
          <p className="text-3xl font-mono text-cyan-400">45</p>
        </div>
      </div>

      {/* Main Charts Grid */}
      <div className="grid grid-cols-12 gap-6">
        {/* Row 1 */}
        <div className="col-span-4 bg-[#0b223d]/30 p-4 rounded border border-cyan-900/50">
          <h3 className="text-sm font-semibold mb-4 border-l-2 border-cyan-400 pl-2">完单率 (基于预估度数)</h3>
          <ReactECharts option={getCompletionOption()} style={{height: '220px'}} />
        </div>
        <div className="col-span-8 bg-[#0b223d]/30 p-4 rounded border border-cyan-900/50">
          <h3 className="text-sm font-semibold mb-4 border-l-2 border-cyan-400 pl-2">结束充电原因分布</h3>
          <ReactECharts option={getEndReasonOption()} style={{height: '220px'}} />
        </div>

        {/* Row 2 */}
        <div className="col-span-6 bg-[#0b223d]/30 p-4 rounded border border-cyan-900/50">
          <h3 className="text-sm font-semibold mb-4 border-l-2 border-cyan-400 pl-2">24小时订单热力分布</h3>
          <ReactECharts option={getHeatmapOption()} style={{height: '250px'}} />
        </div>
        <div className="col-span-6 bg-[#0b223d]/30 p-4 rounded border border-cyan-900/50">
          <h3 className="text-sm font-semibold mb-2 border-l-2 border-cyan-400 pl-2">平均服务流程耗时 (堆叠条形图)</h3>
          <p className="text-right text-gray-400 text-xs mb-2">平均总耗时: 57分钟</p>
          <ReactECharts option={getProcessTimeOption()} style={{height: '180px'}} />
        </div>
      </div>
    </div>
  );
};

// ECharts Options implementations...
function getCompletionOption() {
  return {
    tooltip: { trigger: 'item' },
    series: [{
      type: 'pie',
      radius: ['60%', '85%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 10, borderColor: '#06162d', borderWidth: 2 },
      label: { show: true, position: 'center', formatter: '92%', fontSize: 30, color: '#fff', fontWeight: 'bold' },
      data: [
        { value: 1150, name: '已满足', itemStyle: { color: '#10b981' } },
        { value: 100, name: '未满足', itemStyle: { color: '#f59e0b' } }
      ]
    }]
  };
}

function getProcessTimeOption() {
  return {
    grid: { top: 20, bottom: 40, left: 20, right: 20 },
    xAxis: { show: false },
    yAxis: { show: false, data: ['Time'] },
    series: [
      { name: '响应', type: 'bar', stack: 'total', data: [2], itemStyle: { color: '#22d3ee' } },
      { name: '行驶', type: 'bar', stack: 'total', data: [5], itemStyle: { color: '#3b82f6' } },
      { name: '插枪', type: 'bar', stack: 'total', data: [3], itemStyle: { color: '#a855f7' } },
      { name: '充电', type: 'bar', stack: 'total', data: [45], itemStyle: { color: '#10b981' } },
      { name: '拔枪', type: 'bar', stack: 'total', data: [2], itemStyle: { color: '#f97316' } }
    ]
  };
}

function getEndReasonOption() { return { /* Logic for pie chart */ }; }
function getHeatmapOption() { return { /* Logic for heatmap */ }; }

export default Dashboard;
